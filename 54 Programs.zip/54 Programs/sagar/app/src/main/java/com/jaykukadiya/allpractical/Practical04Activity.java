package com.jaykukadiya.allpractical;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Practical04Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical04);
        EditText input = findViewById(R.id.input);
        Button submit = findViewById(R.id.submit);
        submit.setOnClickListener(v ->
                Toast.makeText(this, input.getText().toString(), Toast.LENGTH_SHORT).show());
    }
}
