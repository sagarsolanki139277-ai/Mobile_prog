package com.jaykukadiya.allpractical;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class Practicals {

    private Practicals() {
    }

    public static List<PracticalLauncher> all() {
        return Collections.unmodifiableList(Arrays.asList(
                new PracticalLauncher(1, "Android Studio & SDK (notes)", Practical01Activity.class),
                new PracticalLauncher(2, "First Android app", Practical02Activity.class),
                new PracticalLauncher(3, "Hello World (colors)", Practical03Activity.class),
                new PracticalLauncher(4, "EditText + Submit → Toast", Practical04Activity.class),
                new PracticalLauncher(5, "Activity lifecycle", Practical05Activity.class),
                new PracticalLauncher(6, "Login → next screen", Practical06Activity.class),
                new PracticalLauncher(7, "Login verify & result screen", Practical07Activity.class),
                new PracticalLauncher(8, "Dial number", Practical08Activity.class),
                new PracticalLauncher(9, "Countries & flag", Practical09Activity.class),
                new PracticalLauncher(10, "Calculator", Practical10Activity.class),
                new PracticalLauncher(11, "ToggleButton", Practical11Activity.class),
                new PracticalLauncher(12, "ImageButton", Practical12Activity.class),
                new PracticalLauncher(13, "ListView", Practical13Activity.class),
                new PracticalLauncher(14, "Spinner", Practical14Activity.class),
                new PracticalLauncher(15, "CheckBox", Practical15Activity.class),
                new PracticalLauncher(16, "RadioButton", Practical16Activity.class),
                new PracticalLauncher(17, "RadioGroup", Practical17Activity.class),
                new PracticalLauncher(18, "ImageView", Practical18Activity.class),
                new PracticalLauncher(19, "TextView, EditText, Button", Practical19Activity.class),
                new PracticalLauncher(20, "RatingBar", Practical20Activity.class),
                new PracticalLauncher(21, "AutoCompleteTextView", Practical21Activity.class),
                new PracticalLauncher(22, "MultiAutoCompleteTextView", Practical22Activity.class),
                new PracticalLauncher(23, "DatePicker", Practical23Activity.class),
                new PracticalLauncher(24, "TimePicker", Practical24Activity.class),
                new PracticalLauncher(25, "ProgressBar", Practical25Activity.class),
                new PracticalLauncher(26, "AnalogClock", Practical26Activity.class),
                new PracticalLauncher(27, "DigitalClock", Practical27Activity.class),
                new PracticalLauncher(28, "RecyclerView", Practical28Activity.class),
                new PracticalLauncher(29, "Context menu", Practical29Activity.class),
                new PracticalLauncher(30, "Tween animation", Practical30Activity.class),
                new PracticalLauncher(31, "RelativeLayout", Practical31Activity.class),
                new PracticalLauncher(32, "TableLayout", Practical32Activity.class),
                new PracticalLauncher(33, "Show URL on screen", Practical33Activity.class),
                new PracticalLauncher(34, "AbsoluteLayout", Practical34Activity.class),
                new PracticalLauncher(35, "Menu: background color", Practical35Activity.class),
                new PracticalLauncher(36, "Frame animation", Practical36Activity.class),
                new PracticalLauncher(37, "WebView", Practical37Activity.class),
                new PracticalLauncher(38, "ActionBar", Practical38Activity.class),
                new PracticalLauncher(39, "Alarm", Practical39Activity.class),
                new PracticalLauncher(40, "Send SMS", Practical40Activity.class),
                new PracticalLauncher(41, "Camera → ImageView", Practical41Activity.class),
                new PracticalLauncher(42, "Service", Practical42Activity.class),
                new PracticalLauncher(43, "AudioManager", Practical43Activity.class),
                new PracticalLauncher(44, "AlertDialog", Practical44Activity.class),
                new PracticalLauncher(45, "Contacts & dial", Practical45Activity.class),
                new PracticalLauncher(46, "SharedPreferences", Practical46Activity.class),
                new PracticalLauncher(47, "Internal storage", Practical47Activity.class),
                new PracticalLauncher(48, "External storage", Practical48Activity.class),
                new PracticalLauncher(49, "Simple & compound interest", Practical49Activity.class),
                new PracticalLauncher(50, "VideoView", Practical50Activity.class),
                new PracticalLauncher(51, "Location", Practical51Activity.class),
                new PracticalLauncher(52, "Sensors", Practical52Activity.class),
                new PracticalLauncher(53, "JSON parsing", Practical53Activity.class),
                new PracticalLauncher(54, "Doctor database", Practical54Activity.class)
        ));
    }
}
