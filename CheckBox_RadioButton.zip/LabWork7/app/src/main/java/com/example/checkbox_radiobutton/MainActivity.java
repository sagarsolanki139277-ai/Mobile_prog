package com.example.checkbox_radiobutton;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = findViewById(R.id.textView);
        CheckBox checkBox = findViewById(R.id.checkBox);

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    textView.setTextSize(30); // Increase font size
                } else {
                    textView.setTextSize(18); // Default size
                }
            }
        });



                ImageView imageView = findViewById(R.id.imageView);
                RadioGroup radioGroup = findViewById(R.id.radioGroup);

                radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(@NonNull RadioGroup group, int checkedId) {
                        if (checkedId == R.id.radioImage1) {
                            imageView.setImageResource(R.drawable.image1);
                        } else if (checkedId == R.id.radioImage2) {
                            imageView.setImageResource(R.drawable.image2);
                        }
                    }
                });

    }
}
