package com.example.prog18;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    ProgressBar pg;
    int progressStatus;

    Handler handler=new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        pg=findViewById(R.id.progressBar2);

        new Thread(new Runnable() {
            @Override
            public void run() {
                while(progressStatus<100){
                    progressStatus+=1;
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            pg.setProgress(progressStatus);
                        }
                    });

                    try{
                        Thread.sleep(50);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }).start();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent iNext=new Intent(MainActivity.this,MainActivity2.class);
                startActivity(iNext);
                MainActivity.this.finish();
            }
        },5000);
    }
}