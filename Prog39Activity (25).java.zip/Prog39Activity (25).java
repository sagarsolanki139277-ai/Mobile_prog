package com.sagar.allpractical;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Practical26Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical26);
    }
}
