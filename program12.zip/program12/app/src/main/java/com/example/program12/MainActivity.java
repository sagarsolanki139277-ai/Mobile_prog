package com.example.program12;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        imageView = findViewById(R.id.imageView);

        Button btnAlpha = findViewById(R.id.btnAlpha);
        Button btnRotate = findViewById(R.id.btnRotate);
        Button btnScale = findViewById(R.id.btnScale);
        Button btnTranslate = findViewById(R.id.btnTranslate);

        btnAlpha.setOnClickListener(v -> {
            Animation animation = AnimationUtils.loadAnimation(this, R.anim.alpha);
            textView.startAnimation(animation);
        });

        btnRotate.setOnClickListener(v -> {
            Animation animation = AnimationUtils.loadAnimation(this, R.anim.rotate);
            textView.startAnimation(animation);
        });

        btnScale.setOnClickListener(v -> {
            Animation animation = AnimationUtils.loadAnimation(this, R.anim.scale);
            textView.startAnimation(animation);
        });

        btnTranslate.setOnClickListener(v -> {
            Animation animation = AnimationUtils.loadAnimation(this, R.anim.translate);
            textView.startAnimation(animation);
        });

        // Start Frame Animation
        imageView.post(() -> {
            AnimationDrawable animationDrawable =
                    (AnimationDrawable) imageView.getBackground();
            animationDrawable.start();
        });
    }
}