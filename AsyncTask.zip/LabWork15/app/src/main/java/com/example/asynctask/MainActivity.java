package com.example.asynctask;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button startTaskButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startTaskButton = findViewById(R.id.startTaskButton);

        // When button is clicked, run AsyncTask
        startTaskButton.setOnClickListener(v -> new DelayedTask(MainActivity.this).execute());
    }

    // AsyncTask class
    private static class DelayedTask extends AsyncTask<Void, Void, String> {

        @SuppressLint("StaticFieldLeak")
        private Context context;

        DelayedTask(Context context) {
            this.context = context;
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                // Simulate a delay of 3 seconds
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return "Task executed after 3 seconds!";
        }

        @Override
        protected void onPostExecute(String result) {
            // Show the result in an AlertDialog
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("AsyncTask Result")
                    .setMessage(result)
                    .setPositiveButton("OK", null)
                    .show();
        }
    }
}
