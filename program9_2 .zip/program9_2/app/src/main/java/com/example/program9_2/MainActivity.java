package com.example.program9_2;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView autoText;
    MultiAutoCompleteTextView multiAutoText;

    String[] countries = {
            "India", "Australia", "America", "China",
            "Japan", "Germany", "France", "Italy", "Brazil"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        autoText = findViewById(R.id.autoText);
        multiAutoText = findViewById(R.id.multiAutoText);

        // Adapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                countries
        );

        // Set adapter
        autoText.setAdapter(adapter);

        multiAutoText.setAdapter(adapter);
        multiAutoText.setTokenizer(
                new MultiAutoCompleteTextView.CommaTokenizer()
        );
    }
}
