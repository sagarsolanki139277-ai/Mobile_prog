package com.example.program9;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<User> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();
        list.add(new User("John Wick", "john.wick@email.com", R.drawable.f));
        list.add(new User("Robert J", "robert.j@email.com", R.drawable.b));
        list.add(new User("James Gunn", "james.gunn@email.com", R.drawable.c));
        list.add(new User("Ricky Tales", "ricky.tales@email.com", R.drawable.d));
        list.add(new User("Micky Mose", "mickey.mouse@email.com", R.drawable.e));



        MyAdapter adapter = new MyAdapter(list);
        recyclerView.setAdapter(adapter);
    }
}
