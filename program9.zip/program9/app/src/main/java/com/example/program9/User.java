package com.example.program9;
public class User {
    String name, email;
    int image;

    public User(String name, String email, int image) {
        this.name = name;
        this.email = email;
        this.image = image;
    }
}
