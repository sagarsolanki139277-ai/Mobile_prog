package com.sagar.allpractical;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class Practical35Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_practical35);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Menu background colors");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_bg_colors, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        FrameLayout root = findViewById(R.id.root);
        int id = item.getItemId();
        if (id == R.id.bg_red) {
            root.setBackgroundColor(Color.parseColor("#FFCDD2"));
            return true;
        } else if (id == R.id.bg_green) {
            root.setBackgroundColor(Color.parseColor("#C8E6C9"));
            return true;
        } else if (id == R.id.bg_blue) {
            root.setBackgroundColor(Color.parseColor("#BBDEFB"));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
